# jmeter-kubernetes

Please follow the guide "Load Testing As A Service With Jmeter On Kubernetes" via medium:

https://goo.gl/mkoX9E
